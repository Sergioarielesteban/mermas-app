export function safeJsonParse<T>(raw: string | null): T | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function isBrowser() {
  return typeof window !== 'undefined' && typeof localStorage !== 'undefined';
}

